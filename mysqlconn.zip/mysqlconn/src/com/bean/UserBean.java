package com.bean;

import java.io.IOException;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.predefined.Alllocations;
import com.predefined.InventoryTable;
import com.predefined.Sales_report;

import mphasis.logo.Dbconnection;

@SuppressWarnings("deprecation")
@SessionScoped
@ManagedBean(name="userBean")
public class UserBean extends Dbconnection{
	

	
	private String userName;
	private Integer id;
	private String password;
	private List<InventoryTable> inventoryTableData;
	
	
	
	



	public List<InventoryTable> getInventoryTableData() {
		return inventoryTableData;
	}


	public void setInventoryTableData(List<InventoryTable> inventoryTableData) {
		this.inventoryTableData = inventoryTableData;
	}



	private List<String> tableList;
	
	  
	  
	  public List<String> getTableList() {
		return tableList;
	}


	public void setTableList(List<String> tableList) {
		this.tableList = tableList;
	}

    @PostConstruct
	public void init() {
		  tableList =new ArrayList<String>();
			 
			try {
			
				Connection connection=Dbconnection.getConnection();
				
				PreparedStatement ps =connection.prepareStatement("SELECT table_name FROM information_schema.tables WHERE table_schema = 'salesreport'");
				
			 ResultSet results=	ps.executeQuery();
			 
			 while(results.next()) {
			String table=	 results.getString(1);
			
				 
			tableList.add(table);
			 }
			
			 
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
			
		
		
			  
			}
	



	

		public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}



@SuppressWarnings("unused")
public String add() throws IOException {
	User userdetail = new User(this.userName, this.password);
	Connection connection=Dbconnection.getConnection();
	int i=0;
	try {
		PreparedStatement ps =connection.prepareStatement("insert into salesreport.logincredentials values(?,?,?,?)");
		ps.setString(1,this.userName);
		ps.setInt(2,this.id);
		ps.setString(4, this.password);

     
		
		
	 i=	ps.executeUpdate();		
	 if(i==1){
		 System.out.println("successully registered");
		 return "index.xhtml";
	 }
	}catch (SQLException e) {
	
		e.printStackTrace();
	}
	 
	return null;
	
}







public 	String inventory() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory`  ";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
		
		
		}




public 	String DSD() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory` where FEED_ID ='DSDN'";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
			}



public 	String Franchise() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory` where STORE_NUMBER In(009, 021, 023)";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
			}




public 	String NonDSD() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory` where FEED_ID In('NDSDN','SRSC')";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
			}




public 	String WareHouse() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory` where FEED_ID In('AB+C1','SRSC')";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
			}


public 	String Manufacturing() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory` where FEED_ID In('AB+C1','GAINT','SRSC','ABCD')";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
			}


public 	String Other() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory` where FEED_ID In('AB+C1','ABCD')";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
			}








public void postProcessXLS(Object document) {
    HSSFWorkbook wb = (HSSFWorkbook) document;
    HSSFSheet sheet = wb.getSheetAt(0);
    CellStyle style = wb.createCellStyle();
    style.setFillBackgroundColor(IndexedColors.AQUA.getIndex());

    for (Row row : sheet) {
        for (Cell cell : row) {
            cell.setCellValue(cell.getStringCellValue().toUpperCase());
            cell.setCellStyle(style);
        }
    }
}
public void preProcesoPDF(Object document) throws IOException, BadElementException, DocumentException {
    System.out.println("PREPROCESO");

    Document pdf = (Document) document;
    try {
        pdf.setPageSize(PageSize.A2.rotate());
        pdf.setMargins(0.9f,0.9f,0.9f,0.9f);
    } catch (Exception e) {
        e.printStackTrace();
    }

    if (!pdf.isOpen()) {
        pdf.open();
    }
}



}

		
			



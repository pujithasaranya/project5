 package com.bean;

import java.io.IOException;
import java.io.Serializable;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;

import com.predefined.InventoryTable;

import mphasis.logo.Dbconnection;
import sun.util.calendar.BaseCalendar.Date;

@SuppressWarnings("deprecation")
@ManagedBean(name="userDef")
@SessionScoped
public class UserDefined extends Dbconnection implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int sTORE_NUMBER;
	
	private int dEPARTMENT;
	
	private int wEEK_ENDING_DD; 
	
	private int  wEEK_ENDING_YEAR;
	
	public Date getsTARTDATE() {
		System.out.println(sTARTDATE);
		return sTARTDATE;
	}


	public void setsTARTDATE(Date sTARTDATE) {
		System.out.println(sTARTDATE);
		this.sTARTDATE = sTARTDATE;
	}


	public Date geteNDDATE() {
		System.out.println(eNDDATE);
		return eNDDATE;
	}


	public void seteNDDATE(Date eNDDATE) {
		System.out.println(eNDDATE);
		this.eNDDATE = eNDDATE;
	}




	private int vENDOR_NUMBER;
	
	private String fEED_ID;
	
	private String lEDGER_DESCRIPTION;
	
	private int wEEK_ENDING_YY;
	
	private int wEEK_ENDING_MM;
	
	private int wEEK_ENDING_CC;
	
	public Date sTARTDATE; 
	
   	public Date eNDDATE;
	
		
	private List<InventoryTable> inventoryTableData;
	

	private List<String> tableList;
	
	  
	  
	  public List<String> getTableList() {
		return tableList;
	}


	public void setTableList(List<String> tableList) {
		this.tableList = tableList;
	}

    @PostConstruct
	public void init() {
		  tableList =new ArrayList<String>();
			 
			try {
			
				Connection connection=Dbconnection.getConnection();
				
				PreparedStatement ps =connection.prepareStatement("SELECT table_name FROM information_schema.tables WHERE table_schema = 'salesreport'");
				
			 ResultSet results=	ps.executeQuery();
			 
			 while(results.next()) {
			String table=	 results.getString(1);
			
				 
			tableList.add(table);
			 }
			
			 
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
			
		
		
			  
			}
	


	private List<String> sTORE_NUMBER_List=new ArrayList<>();
	
	private List<Integer> dEPARTMENT_list=new ArrayList<>();
	
	
	private List<String> wEEK_ENDING_DD_list=new ArrayList<>();
	private List<String> wEEK_ENDING_MM_list=new ArrayList<>();
	private List<String> wEEK_ENDING_YY_list=new ArrayList<>();
	private List<String> wEEK_ENDING_CC_list=new ArrayList<>();
	private List<Integer> wEEK_ENDING_YEAR_list=new ArrayList<>();
	
	private List<Integer> vENDOR_NUMBER_list=new ArrayList<>();
	
	private List<String> fEED_ID_list=new ArrayList<>();
	
	
	private List<String> lEDGER_DESCRIPTION_list=new ArrayList<>();
	
	
	
	public  List<Integer>  get_WEEK_ENDING_YEAR_name(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT  DISTINCT  WEEK_ENDING_YEAR  from  salesreport.inventory");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				wEEK_ENDING_YEAR_list.add(rs.getInt("WEEK_ENDING_YEAR"));
			}
		}catch (Exception e) {
			System.out.println(e);
		}return wEEK_ENDING_YEAR_list;
	}
				
	
	
	
	public  List<Integer>  get_DEPARTMENT_name(){
	try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT  DISTINCT   DEPARTMENT from  salesreport.inventory ORDER BY DEPARTMENT");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
			dEPARTMENT_list.add(rs.getInt("DEPARTMENT"));
				}
				
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return dEPARTMENT_list;
	}
	
	public  List<Integer>  get_DEPARTMENT(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT  DISTINCT   DEPARTMENT from  salesreport.inventory ORDER BY DEPARTMENT");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
			dEPARTMENT_list.add(rs.getInt("DEPARTMENT"));
				}
		} catch (Exception e) {
			System.out.println(e);
		}
		return dEPARTMENT_list;
	}
	
	
	
	public List<String> get_WEEK_ENDING_DD(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT  DISTINCT   WEEK_ENDING_DD from  salesreport.inventory");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				wEEK_ENDING_DD_list.add(rs.getString("WEEK_ENDING_DD"));
			}
			}catch (Exception e) {
				System.out.println(e);
			}
		return wEEK_ENDING_DD_list;
	}
			
	
	
	
	
	public List<String> get_WEEK_ENDING_MM(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT  DISTINCT   WEEK_ENDING_MM from  salesreport.inventory");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				wEEK_ENDING_MM_list.add(rs.getString("WEEK_ENDING_MM"));
			}
			}catch (Exception e) {
				System.out.println(e);
			}
		return wEEK_ENDING_MM_list;
	}
	
	
	public List<String> get_WEEK_ENDING_YY(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT  DISTINCT   WEEK_ENDING_YY from  salesreport.inventory");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				wEEK_ENDING_YY_list.add(rs.getString("WEEK_ENDING_YY"));
			}
			}catch (Exception e) {
				System.out.println(e);
			}
		return wEEK_ENDING_YY_list;
	}
	
	
	
	public List<String> get_WEEK_ENDING_CC(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT  DISTINCT   WEEK_ENDING_CC from  salesreport.inventory");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				wEEK_ENDING_CC_list.add(rs.getString("WEEK_ENDING_CC"));
			}
			}catch (Exception e) {
				System.out.println(e);
			}
		return wEEK_ENDING_CC_list;
	}
	
	
				
	       
	@Override
	public List<String> get_STORE_NUMBER_name(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT DISTINCT STORE_NUMBER from `salesreport`.`inventory` ORDER BY STORE_NUMBER ");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
				sTORE_NUMBER_List.add(rs.getString("STORE_NUMBER"));
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return sTORE_NUMBER_List;
	}
	
	
	@Override
	public List<Integer> get_VENDOR_NUMBER_name(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT DISTINCT VENDOR_NUMBER from `salesreport`.`inventory` ");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
				vENDOR_NUMBER_list.add(rs.getInt("VENDOR_NUMBER"));
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return vENDOR_NUMBER_list;
	}
	
	@Override
	public List<String> get_FEED_ID_name(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT DISTINCT FEED_ID from `salesreport`.`inventory` ");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
				fEED_ID_list.add(rs.getString("FEED_ID"));
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return fEED_ID_list;
	}

	
	@Override
	public List<String> get_LEDGER_DESCRIPTION_name(){
		try {
			Connection connection=Dbconnection.getConnection();
			PreparedStatement ps=null;
			ps=connection.prepareStatement("SELECT DISTINCT LEDGER_DESCRIPTION from `salesreport`.`inventory` ");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
				lEDGER_DESCRIPTION_list.add(rs.getString("LEDGER_DESCRIPTION"));
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return lEDGER_DESCRIPTION_list;
	}

	public int getsTORE_NUMBER() {
		return sTORE_NUMBER;
	}
	public void setsTORE_NUMBER(int sTORE_NUMBER) {
		this.sTORE_NUMBER = sTORE_NUMBER;
	}
	public int getdEPARTMENT() {
		return dEPARTMENT;
	}
	public void setdEPARTMENT(int dEPARTMENT) {
		this.dEPARTMENT = dEPARTMENT;
	}
	public int getwEEK_ENDING_DD() {
		return wEEK_ENDING_DD;
	}
	public void setwEEK_ENDING_DD(int wEEK_ENDING_DD) {
		this.wEEK_ENDING_DD = wEEK_ENDING_DD;
	}
	public int getwEEK_ENDING_YEAR() {
		return wEEK_ENDING_YEAR;
	}
	public void setwEEK_ENDING_YEAR(int wEEK_ENDING_YEAR) {
		this.wEEK_ENDING_YEAR = wEEK_ENDING_YEAR;
	}
	
	public List<InventoryTable> getInventoryTableData() {
		return inventoryTableData;
	}
	public void setInventoryTableData(List<InventoryTable> inventoryTableData) {
		this.inventoryTableData = inventoryTableData;
	}
	public List<String> getsTORE_NUMBER_List() {
		return sTORE_NUMBER_List;
	}
	public void setsTORE_NUMBER_List(List<String> sTORE_NUMBER_List) {
		this.sTORE_NUMBER_List = sTORE_NUMBER_List;
	}
	public List<Integer> getdEPARTMENT_list() {
		return dEPARTMENT_list;
	}
	public void setdEPARTMENT_list(List<Integer> dEPARTMENT_list) {
		this.dEPARTMENT_list = dEPARTMENT_list;
	}

	public List<String> getwEEK_ENDING_DD_list() {
		return wEEK_ENDING_DD_list;
	}
	public void setwEEK_ENDING_DD_list(List<String> wEEK_ENDING_DD_list) {
		this.wEEK_ENDING_DD_list = wEEK_ENDING_DD_list;
	}
	public List<Integer> getwEEK_ENDING_YEAR_list() {
		return wEEK_ENDING_YEAR_list;
	}
	public void setwEEK_ENDING_YEAR_list(List<Integer> wEEK_ENDING_YEAR_list) {
		this.wEEK_ENDING_YEAR_list = wEEK_ENDING_YEAR_list;
	}
	
	public String getfEED_ID() {
		return fEED_ID;
	}
	public void setfEED_ID(String fEED_ID) {
		this.fEED_ID = fEED_ID;
	}
	public List<String> getfEED_ID_list() {
		return fEED_ID_list;
	}
	public void setfEED_ID_list(List<String> fEED_ID_list) {
		this.fEED_ID_list = fEED_ID_list;
	}
	public int getvENDOR_NUMBER() {
		return vENDOR_NUMBER;
	}
	public void setvENDOR_NUMBER(int vENDOR_NUMBER) {
		this.vENDOR_NUMBER = vENDOR_NUMBER;
	}
	public List<Integer> getvENDOR_NUMBER_list() {
		return vENDOR_NUMBER_list;
	}
	public void setvENDOR_NUMBER_list(List<Integer> vENDOR_NUMBER_list) {
		this.vENDOR_NUMBER_list = vENDOR_NUMBER_list;
	}
	
	
	
	
	
	
	public String getlEDGER_DESCRIPTION() {
		return lEDGER_DESCRIPTION;
	}


	public void setlEDGER_DESCRIPTION(String lEDGER_DESCRIPTION) {
		this.lEDGER_DESCRIPTION = lEDGER_DESCRIPTION;
	}


	public List<String> getlEDGER_DESCRIPTION_list() {
		return lEDGER_DESCRIPTION_list;
	}


	public void setlEDGER_DESCRIPTION_list(List<String> lEDGER_DESCRIPTION_list) {
		this.lEDGER_DESCRIPTION_list = lEDGER_DESCRIPTION_list;
	}
	
	public int getwEEK_ENDING_MM() {
		return wEEK_ENDING_MM;
	}


	public void setwEEK_ENDING_MM(int wEEK_ENDING_MM) {
		this.wEEK_ENDING_MM = wEEK_ENDING_MM;
	}


	public int getwEEK_ENDING_YY() {
		return wEEK_ENDING_YY;
	}


	public void setwEEK_ENDING_YY(int wEEK_ENDING_YY) {
		this.wEEK_ENDING_YY = wEEK_ENDING_YY;
	} 

	public int getwEEK_ENDING_CC() {
		return wEEK_ENDING_CC;
	}


	public void setwEEK_ENDING_CC(int wEEK_ENDING_CC) {
		this.wEEK_ENDING_CC = wEEK_ENDING_CC;
	}

	public List<String> get_list() {
		return wEEK_ENDING_MM_list;
	}


	public void setwEEK_ENDING_MM_list(List<String> wEEK_ENDING_MM_list) {
		this.wEEK_ENDING_MM_list = wEEK_ENDING_MM_list;
	}


	public List<String> getwEEK_ENDING_YY_list() {
		return wEEK_ENDING_YY_list;
	}


	public void setwEEK_ENDING_YY_list(List<String> wEEK_ENDING_YY_list) {
		this.wEEK_ENDING_YY_list = wEEK_ENDING_YY_list;
	}


	public List<String> getwEEK_ENDING_CC_list() {
		return wEEK_ENDING_CC_list;
	}


	public void setwEEK_ENDING_CC_list(List<String> wEEK_ENDING_CC_list) {
		this.wEEK_ENDING_CC_list = wEEK_ENDING_CC_list;
	}


	
	
	
	public String fetchData() {
	inventoryTableData=new ArrayList<>();
	int s=sTORE_NUMBER;
	int d=dEPARTMENT;
	int y=wEEK_ENDING_YEAR;
	int v=vENDOR_NUMBER;
	String f=fEED_ID;
	String l=lEDGER_DESCRIPTION;
	Date st = sTARTDATE; 
	Date ed = eNDDATE;
	
	
	
	
		try {
		Connection connection=Dbconnection.getConnection();
		PreparedStatement pso=null;
		/* PreparedStatement pso1=null; */
		String qry="select * from `salesreport`.`inventory`  where STORE_NUMBER=? AND DEPARTMENT=? AND WEEK_ENDING_YEAR=? AND CONCAT(WEEK_ENDING_DD,\"/\",WEEK_ENDING_MM,\"/\",WEEK_ENDING_CC,WEEK_ENDING_YY) BETWEEN '?'  AND '?' ";
	
		if( v>0 ) {
			qry+=" AND VENDOR_NUMBER=?";
		}
		
		if(l !=null) {
			qry+=" AND LEDGER_DESCRIPTION=?";
		}
		
		
		if(f !=null) {
			qry+="AND FEED_ID=? ";
		}
		
		pso=connection.prepareStatement(qry);
		System.out.println("************ STORE_NUMBER"+s);
		System.out.println("************Depar"+d);
		System.out.println("************Year"+y);
		System.out.println("************vendor"+v);
		System.out.println("************feed"+f);
		System.out.println("************led"+l);
		System.out.println("************Start Date"+st);
		System.out.println("************End Date "+ed);
		pso.setInt(1, s );
		pso.setInt(2, d);
		pso.setInt(3, y);
		
		
		if( v>0 ) {
			pso.setInt(4, v);
			if(l !=null) {
				pso.setString(5, l);
				}
		
		}
		else if(l !=null){
			pso.setString(4, l);
			}
		if(f !=null) {
			pso.setString(6, f);

		}
		 
		
		
		ResultSet rso=pso.executeQuery();
		
		
			
			 int countO=0;
				while(rso.next()) {
					InventoryTable ITO=new InventoryTable();
					
					ITO.setfEED_ID(rso.getString("FEED_ID"));
					ITO.setwEEK_ENDING_YEAR(rso.getInt("WEEK_ENDING_YEAR"));
					ITO.setwEEK_ENDING_CC(rso.getInt("WEEK_ENDING_CC"));
					ITO.setwEEK_ENDING_YY(rso.getInt("WEEK_ENDING_YY"));
					ITO.setwEEK_ENDING_MM(rso.getInt("WEEK_ENDING_MM"));
					ITO.setwEEK_ENDING_DD(rso.getInt("WEEK_ENDING_DD"));
					ITO.setdEPARTMENT_FLAG(rso.getString("DEPARTMENT_FLAG"));
					ITO.setcORP(rso.getInt("CORP"));
					ITO.setcOMPANY(rso.getInt("COMPANY"));
					ITO.setsTORE_NUMBER(rso.getInt("STORE_NUMBER"));
					ITO.setdEPARTMENT(rso.getInt("DEPARTMENT"));
					ITO.setcHRG_CD_MAJOR(rso.getInt("CHRG_CD_MAJOR"));
					ITO.setcHRG_CD_MINOR(rso.getInt("CHRG_CD_MINOR"));
					ITO.setcHRG_CD_SRC(rso.getInt("CHRG_CD_SRC"));
					ITO.setiTEM_NUMBER(rso.getString("ITEM_NUMBER"));
					ITO.setcOST(rso.getString("COST"));
					ITO.setrETAIL(rso.getString("RETAIL"));
					ITO.setlEDGER_DESCRIPTION(rso.getString("LEDGER_DESCRIPTION"));
					ITO.setvENDOR_NUMBER(rso.getString("VENDOR_NUMBER"));
					ITO.setiNVOICE_NUMBER(rso.getString("INVOICE_NUMBER"));
					ITO.setpO_NUMBER(rso.getString("PO_NUMBER"));
					ITO.setaDJ_REASONS(rso.getString("ADJ_REASONS"));
					
					countO++;
					
					inventoryTableData.add(ITO);
				}	
				System.out.println(countO);
				
				return "Userdata";	
					
			}	

			
			 catch (SQLException e) {
			
				e.printStackTrace();
			}
			
			return null;
				}
	
	
	public void postProcessXLS1(Object document1) {
	    HSSFWorkbook wb1 = (HSSFWorkbook) document1;
	    HSSFSheet sheet1 = wb1.getSheetAt(0);
	    CellStyle style1 = wb1.createCellStyle();
	    style1.setFillBackgroundColor(IndexedColors.AQUA.getIndex());

	    for (Row row1 : sheet1) {
	        for (Cell cell1 : row1) {
	            cell1.setCellValue(cell1.getStringCellValue().toUpperCase());
	            cell1.setCellStyle(style1);
	        }
	    }
	}
	public void preProcesoPDF1(Object document2) throws IOException, BadElementException, DocumentException {
	    System.out.println("PREPROCESO");

	    Document pdf1 = (Document) document2;
	    try {
	        pdf1.setPageSize(PageSize.A2.rotate());
	        pdf1.setMargins(0.9f,0.9f,0.9f,0.9f);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    if (!pdf1.isOpen()) {
        pdf1.open();
	    }
	}


	
	


  
	

	
}
package com.bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.security.auth.login.FailedLoginException;

import org.primefaces.context.RequestContext;

import mphasis.logo.Dbconnection;



@ManagedBean(name="loginbean")
@SuppressWarnings("deprecation")
public class LoginBean extends Dbconnection{
	@Inject
	StoreNumber storeNumber;
	
	
	private String userName;
	private String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	public String authenticate() throws FailedLoginException {
		
		
		System.out.println("dao class");
		 System.out.println("password:"+this.getPassword());
		 System.out.println("name:"+this.getUserName());
		
		try {
			Connection connection=Dbconnection.getConnection();
			
			PreparedStatement ps =connection.prepareStatement(" select password from salesreport.logincredentials where username=?");
		
			ps.setString(1, this.getUserName());
			

			
			 String userpwd=this.getPassword();
		//	ps.setString(2, this.getPassword());
			ResultSet results=	ps.executeQuery();
			
			if(results.next()) {
				 String user=results.getString(1);
				 String pwd=results.getString(1);
				
				 
				 System.out.println(pwd);
				 System.out.println("-----------------------");
				 System.out.println(userpwd);
				 
				 FacesMessage message;
				if(user.equals(userName) || pwd.equals(userpwd)) {
			 System.out.println("successfully logged");
			 
			 Vendor v=new Vendor();
			 try {
				v.changevalue();
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			 
			return "Welcome.xhtml";
				 }
			
				
			else {
				message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
						"Error during saving data");
			}
					RequestContext.getCurrentInstance().showMessageInDialog(message);
					return null;
				     
				}
		 
		}	
			catch (SQLException e) {
				
		
			e.printStackTrace();
			throw new FailedLoginException("String msg");
			

		}
		return null;
	}
	
	
	
	
	
	}


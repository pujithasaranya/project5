package com.bean;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.event.ValueChangeEvent;

import com.mysql.cj.protocol.Resultset;

import mphasis.logo.Dbconnection;
@ManagedBean
public class StoreNumber  extends  Dbconnection implements Serializable {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private static Map<String,String> stores;
private List<Integer> dept;
private int store_number;

private List<String> store_dept;

public List<String> getStore_dept() {
	return store_dept;
}

public void setStore_dept(List<String> store_dept) {
	this.store_dept = store_dept;
}



private int store_num; 
	public int getStore_num() {
	return store_num;
}

public void setStore_num(int store_num) {
	this.store_num = store_num;
}

	public List<Integer> getDept() {
	return dept;
}

public void setDept(List<Integer> dept) {
	this.dept = dept;
}



	public int getStore_number() {
	return store_number;
}

public void setStore_number(int store_number) {
	this.store_number = store_number;
}



	private String localeCode = "A"; //default value 
	
	static{
		stores = new LinkedHashMap<String,String>();
		stores.put("25", "A"); //label, value
		stores.put("26", "B");
		stores.put("27", "C");
		stores.put("28", "D");
	}

	public void countryLocaleCodeChanged(ValueChangeEvent e){
		//assign new value to localeCode
		localeCode = e.getNewValue().toString();
		
	}

	public Map<String,String> getCountryInMap() {
		return this.stores;
	}

	public String getLocaleCode() {
		return localeCode;
	}

	public void setLocaleCode(String localeCode) {
		this.localeCode = localeCode;
	}
	
	
	  @PostConstruct public void value() {
	   dept=new ArrayList<>(); Connection
	  con=Dbconnection.getConnection(); String
	  sql="select DEPARTMENT from salesreport.inventory"; try {
	  PreparedStatement ps=con.prepareStatement(sql);
	  
	  ResultSet rs=ps.executeQuery(); while(rs.next()) {
	  
	  if(dept.contains(rs.getInt("DEPARTMENT"))) {
	  
	  } else { dept.add(rs.getInt("DEPARTMENT"));
	  
	  }
	  
	  }
	  
	  } catch (SQLException e) {
	  
	  e.printStackTrace(); }
	  
	  
	  }
	 
	
	public void codeChanged(ValueChangeEvent e){
	
		localeCode = e.getNewValue().toString();
		
		Connection con=Dbconnection.getConnection();
		String sql="select STORE_NUMBER from salesreport.inventory where DEPARTMENT=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, localeCode);
			
			ResultSet rs=ps.executeQuery();
			int ss=0;
		if(rs.next()) {
				
				 ss=rs.getInt("STORE_NUMBER");
				
				 this.setStore_number(ss);
				
				
			}
			
		} catch (SQLException es) {
			
			es.printStackTrace();
		}
		
	}
	
	/*
	 * @PostConstruct public void valuess() { dept=new ArrayList<>(); store_dept=new
	 * ArrayList<>(); Connection con=Dbconnection.getConnection(); String
	 * sql="select DEPARTMENT,STORE_NUMBER from salesreportdatabase.inventorytable";
	 * try { PreparedStatement ps=con.prepareStatement(sql);
	 * 
	 * ResultSet rs=ps.executeQuery(); while(rs.next()) {
	 * 
	 * if(dept.contains(rs.getInt("DEPARTMENT")) {
	 * 
	 * } else { dept.add(rs.getInt("DEPARTMENT")); String
	 * dep=Integer.toString(rs.getInt("DEPARTMENT")); String
	 * s=Integer.toString(rs.getInt("STORE_NUMBER"));
	 * 
	 * 
	 * String c= dep+","+s; System.out.println(c); store_dept.add(c);
	 * 
	 * 
	 * }
	 * 
	 * }
	 * 
	 * } catch (SQLException e) {
	 * 
	 * e.printStackTrace(); }
	 * 
	 * 
	 * }
	 */
	

}

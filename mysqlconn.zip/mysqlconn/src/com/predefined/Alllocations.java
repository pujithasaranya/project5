package com.predefined;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;

import mphasis.logo.Dbconnection;


@ManagedBean(name="bean")
public class Alllocations extends Dbconnection{

	private String FEED_ID;
	private String WKENDINGDATE;
	private int YEAR;
	private int STORE_NUMBER;
	
	private int DEPARTMENT;
	private String VENDOR_NO;
	private String VENDOR_NAME;
	private String STORE_TYPE;
	public String getFEED_ID() {
		return FEED_ID;
	}
	public void setFEED_ID(String fEED_ID) {
		FEED_ID = fEED_ID;
	}
	public String getWKENDINGDATE() {
		return WKENDINGDATE;
	}
	public void setWKENDINGDATE(String wKENDINGDATE) {
		WKENDINGDATE = wKENDINGDATE;
	}
	public int getYEAR() {
		return YEAR;
	}
	public void setYEAR(int yEAR) {
		YEAR = yEAR;
	}
	public int getSTORE_NUMBER() {
		return STORE_NUMBER;
	}
	public void setSTORE_NUMBER(int sTORE_NUMBER) {
		STORE_NUMBER = sTORE_NUMBER;
	}
	public int getDEPARTMENT() {
		return DEPARTMENT;
	}
	public void setDEPARTMENT(int dEPARTMENT) {
		DEPARTMENT = dEPARTMENT;
	}
	public String getVENDOR_NO() {
		return VENDOR_NO;
	}
	public void setVENDOR_NO(String vENDOR_NO) {
		VENDOR_NO = vENDOR_NO;
	}
	public String getVENDOR_NAME() {
		return VENDOR_NAME;
	}
	public void setVENDOR_NAME(String vENDOR_NAME) {
		VENDOR_NAME = vENDOR_NAME;
	}
	public String getSTORE_TYPE() {
		return STORE_TYPE;
	}
	public void setSTORE_TYPE(String sTORE_TYPE) {
		STORE_TYPE = sTORE_TYPE;
	}
	
	
}



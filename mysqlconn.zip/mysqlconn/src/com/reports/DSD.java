package com.reports;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;

import com.predefined.InventoryTable;

import mphasis.logo.Dbconnection;
@SuppressWarnings("deprecation")
@ManagedBean(name="reports")
public class DSD extends Dbconnection {
	
	private List<InventoryTable> inventoryTableData;
	

	public List<InventoryTable> getInventoryTableData() {
		return inventoryTableData;
	}



	public void setInventoryTableData(List<InventoryTable> inventoryTableData) {
		this.inventoryTableData = inventoryTableData;
	}

	

public 	String DSDN() {
	System.out.println("dao class");

	inventoryTableData =new ArrayList<InventoryTable>();
		try {
			Connection connection=Dbconnection.getConnection();
			
			String sql="select * from `salesreport`.`inventory` where FEED_ID ='ABC1'";
			
			//System.out.println(sql);
			
			PreparedStatement ps8 =connection.prepareStatement(sql);
			
			
		 ResultSet rs=	ps8.executeQuery();
		 int count=0;
			while(rs.next()) {
				InventoryTable IT=new InventoryTable();
				
				IT.setfEED_ID(rs.getString("FEED_ID"));
				IT.setwEEK_ENDING_YEAR(rs.getInt("WEEK_ENDING_YEAR"));
				IT.setwEEK_ENDING_CC(rs.getInt("WEEK_ENDING_CC"));
				IT.setwEEK_ENDING_YY(rs.getInt("WEEK_ENDING_YY"));
				IT.setwEEK_ENDING_MM(rs.getInt("WEEK_ENDING_MM"));
				IT.setwEEK_ENDING_DD(rs.getInt("WEEK_ENDING_DD"));
				IT.setdEPARTMENT_FLAG(rs.getString("DEPARTMENT_FLAG"));
				IT.setcORP(rs.getInt("CORP"));
				IT.setcOMPANY(rs.getInt("COMPANY"));
				IT.setsTORE_NUMBER(rs.getInt("STORE_NUMBER"));
				IT.setdEPARTMENT(rs.getInt("DEPARTMENT"));
				IT.setcHRG_CD_MAJOR(rs.getInt("CHRG_CD_MAJOR"));
				IT.setcHRG_CD_MINOR(rs.getInt("CHRG_CD_MINOR"));
				IT.setcHRG_CD_SRC(rs.getInt("CHRG_CD_SRC"));
				IT.setiTEM_NUMBER(rs.getString("ITEM_NUMBER"));
				IT.setcOST(rs.getString("COST"));
				IT.setrETAIL(rs.getString("RETAIL"));
				IT.setlEDGER_DESCRIPTION(rs.getString("LEDGER_DESCRIPTION"));
				IT.setvENDOR_NUMBER(rs.getString("VENDOR_NUMBER"));
				IT.setiNVOICE_NUMBER(rs.getString("INVOICE_NUMBER"));
				IT.setpO_NUMBER(rs.getString("PO_NUMBER"));
				IT.setaDJ_REASONS(rs.getString("ADJ_REASONS"));
				
				count++;
				
				inventoryTableData.add(IT);
			}		

	System.out.println(count);
				
			return "Inventory";	
				
		}	

		
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return null;
		
		
		}



}
